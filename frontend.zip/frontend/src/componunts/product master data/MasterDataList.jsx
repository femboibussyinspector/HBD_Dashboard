import React, { useState, useEffect } from 'react';
import ReusableTable from '../Table/ReusableTable'; 

const MasterDataList = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  // THIS IS THE ONLY THING THAT CHANGES
  const masterColumns = [
    { 
      header: "Business Name", 
      accessor: "business_name", // Matches Python: business_name
      render: (row) => (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span style={{ fontWeight: 'bold' }}>{row.business_name}</span>
          <span style={{ fontSize: '11px', color: '#666' }}>{row.business_id}</span>
        </div>
      )
    },
    { 
      header: "Category", 
      accessor: "business_category", // Matches Python: business_category
      render: (row) => (
        <span style={{ 
          backgroundColor: '#e0f2f1', 
          color: '#00695c', 
          padding: '2px 8px', 
          borderRadius: '4px',
          fontSize: '12px'
        }}>
          {row.business_category}
        </span>
      )
    },
    { 
      header: "Contact Info", 
      accessor: "primary_phone", 
      render: (row) => (
        <div style={{ display: 'flex', flexDirection: 'column', fontSize: '13px' }}>
          <span>📞 {row.primary_phone}</span>
          {row.email && <span style={{ color: 'blue' }}>✉️ {row.email}</span>}
        </div>
      )
    },
    { 
      header: "Location", 
      accessor: "city", 
      render: (row) => (
        <span>{row.city}, {row.state}</span>
      )
    },
    { 
      header: "Rating", 
      accessor: "ratings", // Matches Python: ratings
      render: (row) => (
        <span style={{ fontWeight: 'bold', color: '#f57f17' }}>
          {row.ratings ? `${row.ratings} ⭐` : 'N/A'}
        </span>
      )
    },
    { 
      header: "Links", 
      accessor: "website_url",
      render: (row) => (
        <div style={{ display: 'flex', gap: '5px' }}>
          {row.website_url && <a href={row.website_url} target="_blank" rel="noreferrer">🌐</a>}
          {row.facebook_url && <a href={row.facebook_url} target="_blank" rel="noreferrer">fb</a>}
        </div>
      )
    }
  ];

  useEffect(() => {
    // Replace with your actual Flask endpoint that returns list of MasterTable objects
    fetch('http://localhost:5000/api/master-data') 
      .then((response) => response.json())
      .then((apiData) => {
        setData(apiData);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching master data:", error);
        setLoading(false);
      });
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h2>Master Data Registry</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <ReusableTable columns={masterColumns} data={data} />
      )}
    </div>
  );
};

export default MasterDataList;