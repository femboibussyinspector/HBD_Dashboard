import React, { useState, useEffect } from 'react';
import ReusableTable from '../Table/ReusableTable'; 

const MasterDataRegistry = () => {
  const [allData, setAllData] = useState([]);
  const [loading, setLoading] = useState(true);

  // Configuration mapping exactly to your Python 'MasterTable' model
  const columns = [
    { 
      header: "Business / Product", 
      accessor: "business_name",
      render: (row) => (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span style={{ fontWeight: 'bold', color: '#333' }}>{row.business_name}</span>
          <span style={{ fontSize: '11px', color: '#888' }}>ID: {row.global_business_id}</span>
        </div>
      )
    },
    { 
      header: "Source", 
      accessor: "data_source", 
      render: (row) => (
        <span style={{ 
          fontWeight: 'bold', 
          color: '#007bff',
          textTransform: 'uppercase',
          fontSize: '12px'
        }}>
          {row.data_source || 'N/A'}
        </span>
      )
    },
    { 
      header: "Category", 
      accessor: "business_category",
      render: (row) => (
        <span style={{ 
          backgroundColor: '#eee', 
          padding: '2px 6px', 
          borderRadius: '4px', 
          fontSize: '12px' 
        }}>
          {row.business_category}
        </span>
      )
    },
    { 
      header: "Contact", 
      accessor: "primary_phone",
      render: (row) => (
        <div style={{ display: 'flex', flexDirection: 'column', fontSize: '13px' }}>
          <span>📞 {row.primary_phone || '--'}</span>
          {row.email && <span style={{ color: '#555' }}>✉️ {row.email}</span>}
        </div>
      )
    },
    { 
      header: "Location", 
      accessor: "city",
      render: (row) => (
        <span>{row.city}, {row.state}</span>
      )
    },
    { 
      header: "Rating", 
      accessor: "ratings",
      render: (row) => (
        <span style={{ fontWeight: 'bold', color: '#f57f17' }}>
          {row.ratings ? `${row.ratings} ⭐` : '-'}
        </span>
      )
    }
  ];

  useEffect(() => {
    // 👇 Ensure your Backend has this specific route that returns "SELECT * FROM master_table"
    fetch('http://localhost:5000/api/get-all-master-data') 
      .then((response) => response.json())
      .then((data) => {
        setAllData(data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching master registry:", error);
        setLoading(false);
      });
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>Central Master Data Registry</h2>
        <span style={{ fontSize: '14px', color: '#666' }}>
          Total Records: {allData.length}
        </span>
      </div>

      {loading ? (
        <p>Loading entire database...</p>
      ) : (
        <ReusableTable columns={columns} data={allData} />
      )}
    </div>
  );
};

export default MasterDataRegistry;